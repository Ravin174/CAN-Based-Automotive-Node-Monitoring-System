/*
 * File:   main.c
 * Author: Ravin J S
 *
 * Created on 2 March, 2026, 9:00 AM
 */

#include <xc.h>
#include "main.h"
#include "can.h"
#include "clcd.h"
#include "mkp.h"
#include "adc.h"

#define LEFT    "<-        "
#define HAZARD  "<-      ->"
#define RIGHT   "        ->"
#define OFF     "          "

void init_config(void) 
{
    init_can();
    init_clcd();
    init_matrix_keypad();
    init_adc();
}

// Converts unsigned int (0 - 65535) to string
void uint_to_str(unsigned int num, char *str) {
    char i = 0;

    if (num >= 1000)
    {
        str[i++] = (num / 1000) + '0';
        num %= 1000;
    }
    if (num >= 100 || i > 0) 
    {
        str[i++] = (num / 100) + '0';
        num %= 100;
    }
    if (num >= 10 || i > 0)
    {
        str[i++] = (num / 10) + '0';
        num %= 10;
    }

    str[i++] = num + '0';
    str[i] = '\0';
}

void main(void) 
{
    unsigned int adc_val, rpm, blink_delay = 0;
    char s_rpm[5]; // enough for 6000 + '\0'
    unsigned char key;
    unsigned char blink_flag = 0;

    const char *indicator = OFF;

    init_config();

    clcd_print("RPM: ", LINE1(0));
    clcd_print("IND: ", LINE2(0));

    while (1) 
    {
        /* RPM Calculation */
        adc_val = read_adc(CHANNEL4) / 10.23; // 0?100 approx
        rpm = adc_val * 60; // 0?6000
        uint_to_str(rpm, s_rpm);

        clcd_print("    ", LINE1(5)); // clear old rpm
        clcd_print(s_rpm, LINE1(5));

        /* Switch Handling */
        key = read_switches(STATE_CHANGE);

        if (key == MK_SW1)
            indicator = LEFT;
        else if (key == MK_SW2)
            indicator = HAZARD;
        else if (key == MK_SW3)
            indicator = RIGHT;
        else if (key == MK_SW4)
            indicator = OFF;

        /* Blink Timing */
        if (blink_delay++ >= 750)
        {
            blink_delay = 0;
            blink_flag = !blink_flag;
        }

        /* Display Logic */
        if (indicator == OFF)
        {
            clcd_print(OFF, LINE2(5)); // steady OFF
        } else
        {
            if (blink_flag)
                clcd_print(indicator, LINE2(5));
            else
                clcd_print(OFF, LINE2(5));
        }
    }
}