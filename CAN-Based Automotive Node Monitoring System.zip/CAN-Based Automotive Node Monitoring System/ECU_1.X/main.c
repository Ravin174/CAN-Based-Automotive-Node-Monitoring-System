/*
 * File:   main.c
 * Author: Ravin J S
 *
 * Created on 2 March, 2026, 8:33 AM
 */

#include <xc.h>
#include "main.h"
#include "can.h"
#include "clcd.h"
#include "mkp.h"
#include "adc.h"

void init_config(void) {
    init_can();
    init_clcd();
    init_matrix_keypad();
    init_adc();
}

// Converts unsigned char (0?255) to string without leading zeros except for 0

void uchar_to_str(unsigned char num, char *str) {
    char i = 0;
    if (num >= 100) {
        str[i++] = (num / 100) + '0';
        num %= 100;
    }
    if (num >= 10 || i > 0) {
        str[i++] = (num / 10) + '0';
        num %= 10;
    }
    str[i++] = num + '0';
    str[i] = '\0';
}

void main(void) {
    unsigned int adc_val;
    char s_speed[4];
    unsigned char speed, key, collision = 0, g = 0;
    unsigned char gear[7] = {'N', '1', '2', '3', '4', '5', 'R'};

    init_config();
    
    clcd_print("SPEED: ", LINE1(0));
    clcd_print("KM/H", LINE1(12));
    clcd_print("GEAR: ", LINE2(0));

    while (1) {
        // Scale ADC reading (0?1023) to approximate 0?100 range
        adc_val = read_adc(CHANNEL4) / 10.23;

        speed = adc_val;
        uchar_to_str(speed, s_speed);

        key = read_switches(STATE_CHANGE); // edge-triggered read

        if (key == MK_SW1) {
            if (g < 6) g++; // upshift (max gear 5 + R)
        } else if (key == MK_SW2) {
            if (g > 0) g--; // downshift / neutral
        } else if (key == MK_SW3) {
            collision = 1; // emergency trigger
        }

        if (collision) {
            g = 0;

            CLEAR_DISP_SCREEN;
            clcd_print("COLLISION", LINE1(2));
            clcd_print("DETECTED", LINE2(2));

            __delay_ms(2000);
            collision = 0;

            // Restore normal display labels after alert
            clcd_print("SPEED: ", LINE1(0));
            clcd_print("KM/H", LINE1(12));
            clcd_print("GEAR:     ", LINE2(0));
        }

        // Clear previous speed digits before writing new value
        clcd_print("   ", LINE1(8));

        clcd_print(s_speed, LINE1(7));
        clcd_putch(gear[g], LINE2(6));
    }
    return;
}
