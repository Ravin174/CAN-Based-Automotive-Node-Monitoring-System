/*
 * File:   mkp.c
 * Author: Ravin J S
 *
 * Created on 2 March, 2026, 8:41 AM
 */

#include <xc.h>
#include "mkp.h"

void init_matrix_keypad(void)
{
	/* Configure PORTB as digital */
	ADCON1 = 0x0F;

	/* Set Rows (RB7 - RB5) as Outputs and Columns (RB4 - RB1) as Inputs */
	TRISB = 0x1E;

	/* Set PORTB input as pull up for columns */
	RBPU = 0;

	MATRIX_KEYPAD_PORT = MATRIX_KEYPAD_PORT | 0xE0;
}

unsigned char scan_key(void)
{
	ROW1 = 0;
	ROW2 = 1;
	ROW3 = 1;

	if (COL1 == 0)
	{
		return 1;
	}
	else if (COL2 == 0)
	{
		return 4;
	}
	else if (COL3 == 0)
	{
		return 7;
	}
	else if (COL4 == 0)
	{
		return 10;
	}

	ROW1 = 1;
	ROW2 = 0;
	ROW3 = 1;

	if (COL1 == 0)
	{
		return 2;
	}
	else if (COL2 == 0)
	{
		return 5;
	}
	else if (COL3 == 0)
	{
		return 8;
	}
	else if (COL4 == 0)
	{
		return 11;
	}

	ROW1 = 1;
	ROW2 = 1;
	ROW3 = 0;
	/* TODO: Why more than 2 times? */
	ROW3 = 0;

	if (COL1 == 0)
	{
		return 3;
	}
	else if (COL2 == 0)
	{
		return 6;
	}
	else if (COL3 == 0)
	{
		return 9;
	}
	else if (COL4 == 0)
	{
		return 12;
	}

	return 0xFF;
}

unsigned char read_switches(unsigned char detection_type)
{
	static unsigned char once = 1, key;

	if (detection_type == STATE_CHANGE)
	{
		key = scan_key();
		if(key != 0xFF && once  )
		{
			once = 0;
			return key;
		}
		else if(key == 0xFF)
		{
			once = 1;
		}
	}
	else if (detection_type == LEVEL_CHANGE)
	{
		return scan_key();
	}

	return 0xFF;
}

